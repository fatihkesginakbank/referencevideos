# Change Log

## 0.1.1

- Use <kbd>Cmd</kbd>+click to toggle nodes recursively on macOS

## 0.1.0

- Added offline mode

## 0.0.4

- Fix nested list with depth greater than 10
- Bundle with rollup to decrease package size

## 0.0.2

- Initial release
